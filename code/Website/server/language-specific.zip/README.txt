README

These files are created using the following commands in unix:

1. Find specific languages:

grep "eng:" etymon.tsv >> english.tsv
grep "fra:" etymon.tsv >> french.tsv
grep "fre:" etymon.tsv >> french.tsv
grep "deu:" etymon.tsv >> german.tsv
grep "rus:" etymon.tsv >> russian.tsv
grep "tur:" etymon.tsv >> turkish.tsv
grep "spa:" etymon.tsv >> spanish.tsv
grep "jpn:" etymon.tsv >> japanese.tsv
grep "pol:" etymon.tsv >> polish.tsv
grep "ita:" etymon.tsv >> italian.tsv
grep "swe:" etymon.tsv >> swedish.tsv

2. Find just etmylogies that are sourced on those languages:

grep "eng:.*rel:etymology" english.tsv >> english_etym.tsv
grep "eng:.*rel:etymology" english.tsv >> english_etym.tsv
grep "fra:.*rel:etymology" french.tsv >> french_etym.tsv
grep "fre:.*rel:etymology" french.tsv >> french_etym.tsv
grep "deu:.*rel:etymology" german.tsv >> german_etym.tsv
grep "rus:.*rel:etymology" russian.tsv >> russian_etym.tsv
grep "tur:.*rel:etymology" turkish.tsv >> turkish_etym.tsv
grep "spa:.*rel:etymology" spanish.tsv >> spanish_etym.tsv
grep "jpn:.*rel:etymology" japanese.tsv >> japanese_etym.tsv
grep "pol:.*rel:etymology" polish.tsv >> polish_etym.tsv
grep "ita:.*rel:etymology" italian.tsv >> italian_etym.tsv
grep "swe:.*rel:etymology" swedish.tsv >> swedish_etym.tsv

3. Count how many lines there are in files:
wc -l swedish_etym.tsv 
    9701 swedish_etym.tsv

4. Shuffle the contents of each file:
gshuf english_etym.tsv >> shuff_english.tsv
gshuf french_etym.tsv >> shuff_french.tsv
gshuf german_etym.tsv >> shuff_german.tsv
gshuf russian_etym.tsv >> shuff_russian.tsv 
gshuf turkish_etym.tsv >> shuff_turkish.tsv 
gshuf polish_etym.tsv >> shuff_polish.tsv
gshuf japanese_etym.tsv >> shuff_japanese.tsv
gshuf spanish_etym.tsv >> shuff_spanish.tsv 
gshuf italian_etym.tsv >> shuff_italian.tsv 
gshuf swedish_etym.tsv >> shuff_swedish.tsv

5. Take first 2000 lines of each file:
head -2000 shuff_english.tsv >> 2000_eng.tsv
head -2000 shuff_french.tsv >> 2000_fra.tsv 
head -2000 shuff_german.tsv >> 2000_deu.tsv 
head -2000 shuff_turkish.tsv >> 2000_tur.tsv
head -2000 shuff_arabic.tsv >> 2000_ara.tsv 
head -2000 shuff_russian.tsv >> 2000_rus.tsv
head -2000 shuff_japanese.tsv >> 2000_jpn.tsv
head -2000 shuff_spanish.tsv >> 2000_spa.tsv
head -2000 shuff_italian.tsv >> 2000_ita.tsv
head -2000 shuff_swedish.tsv >> 2000_swe.tsv

6. Concatenate all the data into one training file:
cat 2000_eng.tsv >> training_set.tsv
cat 2000_fra.tsv >> training_set.tsv
cat 2000_tur.tsv >> training_set.tsv
cat 2000_deu.tsv >> training_set.tsv
cat 2000_ara.tsv >> training_set.tsv
cat 2000_rus.tsv >> training_set.tsv
cat 2000_jpn.tsv >> training_set.tsv
cat 2000_spa.tsv >> training_set.tsv
cat 2000_ita.tsv >> training_set.tsv
cat 2000_swe.tsv >> training_set.tsv

7. Characteristics of the training set:
 wc training_set.tsv
   19837  101173  858393 training_set.tsv

8. Shuffle the training set:
gshuf training_set.tsv >> training_set_shuff.tsv
